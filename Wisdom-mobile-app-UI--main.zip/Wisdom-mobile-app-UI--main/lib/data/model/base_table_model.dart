abstract class BaseTableModel {
  Map<String, dynamic> toJson();
}
