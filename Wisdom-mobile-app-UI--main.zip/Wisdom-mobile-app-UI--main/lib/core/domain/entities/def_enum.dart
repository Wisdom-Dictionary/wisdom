enum ThemeOption { day, night }

enum ExerciseType { matching, flipCard }

enum LanguageOption { uzbek, english }

enum RemindOption { manual, auto }
