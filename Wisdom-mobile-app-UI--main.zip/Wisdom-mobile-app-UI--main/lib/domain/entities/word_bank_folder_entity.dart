class WordBankFolderEntity {
  WordBankFolderEntity({required this.id, required this.folderName, required this.isChecked});

  final int id;
  final String folderName;
  bool isChecked;
}
