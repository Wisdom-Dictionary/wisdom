package uz.wisdomedu.wisdom_dictionary

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
