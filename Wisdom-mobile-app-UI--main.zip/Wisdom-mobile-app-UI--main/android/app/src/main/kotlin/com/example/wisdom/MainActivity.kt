package uz.usoft.waiodictionary

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
